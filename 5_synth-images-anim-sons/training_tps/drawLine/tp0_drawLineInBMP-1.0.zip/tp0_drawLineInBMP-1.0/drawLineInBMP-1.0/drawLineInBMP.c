/*!\file DrawLineInBmp.cpp
 *
 * \brief dessin d'un segement de droite en mémoire et sauvegarde dans un fichier BMP.
 *
 * \author Farès Belhadj amsi@up8.edu
 * \date March 02, 2020 -- modifyed on October 27, 2020
 */
#include <stdlib.h>
#include <string.h> /* pour memset */
#include "images_io.h"

#define W 80
#define H 60

static void drawLine(unsigned char * image, int w, int x0, int y0, int x1, int y1, unsigned char color) {
  float y = 0.0f, pente;
  int u = x1 - x0, v = y1 - y0;
  pente = v / (float)u;
  for (int x = 0; x <= u; ++x) {
    image[(y0 + ((int)(y + 0.5f))) * w + x + x0] = color;
    y += pente;
  }
}

int main(void) {
  /* on part sur une image 8 bits / 256 niveaux de gris */
  unsigned char image[H * W];
  /* on met tous les pixels à zéro */
  memset(image, 0, sizeof image);
  /* on dessine une droite de (5, 10) à (70, 50) 
   * la couleur utilisée est le blanc (255)
   */
  drawLine(image, W, 5, 10, 70, 50, 255);
  imageSaveBMP("resu.bmp", image, W, H, 1, 8);
  return EXIT_SUCCESS;
}

/*
 * Exercice 1 : essayez de dessiner le segment (75, 10, 0, 50, 255),
 * ça ne fonctionne pas. Corriger drawLine.
 *
 * Exercice 2 : essayez de dessiner le segment (10, 10, 20, 50, 255),
 * ça ne fonctionne pas. Corriger drawLine.
 * 
 * Exercice 3 : essayez de dessiner le segment (-10, -10, 120, 150,
 * 255), ça ne fonctionne pas. Corriger drawLine.
 *
 * Exercice 4 : dessiner (si ça marche) toutes les positions d'une
 * aiguille trotteuse en variant les intensités de gris. Vous pouvez
 * utiliser cos et sin (inclure math.h) tels que :
 *
 * for (float angle = 0.0f, rayon = 20.0f; angle < 2.0f * M_PI; angle += 0.5f)
 *    drawLine(image, W, W/2, H/2, W/2 + rayon * cos(angle), H/2 + rayon * sin(angle), rand()%256);
 * 
 * Exercice 5 : l'équation d'un cercle est donnée par 
 * 
 * rayon * rayon = (x - x0) * (x - x0) + (y - y0) * (y - y0);
 * écrire drawCircle.
*/
