#include <GL4D/gl4dp.h>
#include <GL4D/gl4dm.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <GL4D/gl4duw_SDL2.h>

enum ca_states_t {
		EMPTY = RGB(102, 204, 0),
		TREE = RGB(175,255,0),
		FIRE = RGB(255,51,0),
		CALCINED = RGB(94, 94, 94)
};

static void initForet(double density, float * lum) {
  GLuint i, wh = gl4dpGetWidth() * gl4dpGetHeight(), * map = gl4dpGetPixels();
  for(i = 0; i < wh; ++i)
    map[i] = (gl4dmURand() < density + (lum[i] * lum[i]) / 2.0f) ? TREE : EMPTY;
}

static void LightFire(void) {
  GLuint i, w = gl4dpGetWidth(), wh = w * gl4dpGetHeight(), * map = gl4dpGetPixels();
  for(i = 0; i < wh; i += w)
    map[i] = (map[i] == TREE) ? FIRE : map[i];
}

static void LightFire2(void) {
  GLuint i,j, w = gl4dpGetWidth(), wh = w * gl4dpGetHeight(), * map = gl4dpGetPixels();
  for(i = 0; i < w; i += 10){
    j = rand()%wh;
    if (map[j] == TREE) map[j] = FIRE;
  }
}

static void quitte(void) {
  gl4duClean(GL4DU_ALL);
}

static void generer(void) {
  GLuint i, w = gl4dpGetWidth(), h = gl4dpGetHeight(), wh = w * h, * map = gl4dpGetPixels();

  GLuint * map_copy = malloc( wh * sizeof *map_copy );

  assert(map_copy);

  memcpy(map_copy, map, wh * sizeof *map_copy);
  /* tout est prêt pour lancer l'automate sur l'ensemble des cellules */
  for(i = 0; i < wh; ++i) {
    switch (map[i]) {
    case EMPTY: /* rien à faire, ou */
    case CALCINED: /* rien à faire aussi */
      break;
    case FIRE: /* il a brulé => devient calciné */
      map[i] = CALCINED;
      break;
    case TREE: /* regardons les voisins */
      {
	/* récupérons l'abscisse et l'ordonnée de la cellule à l'indice i */
	int x = i % w, y = i / w;
	/* l'abscisse et l'ordonnée du voisin (neighbor), un j pour les parcourir */
	int nx, ny, j;
	/* les 4 directions pour le voisinage en 4-connexité */
	const int d[][2] = { /* est   */ { 1,  0},{1, -1},
			     /* nord  */ { 0, -1},{-1,-1},
			     /* ouest */ {-1,  0},{-1, 1},
			     /* sud   */ { 0,  1}, {1,1} };
	for(j = 0; j < 8; ++j) {
	  nx = x + d[j][0];
	  ny = y + d[j][1];
	  if( (nx >= 0 && ny >= 0 && nx < (int) (w) && ny < (int) (h)) /* pour ne pas sortir de la map */ && /* ET ... */
	      map_copy[ny * w + nx] == FIRE /* ... ce voisin <était> en feu */ ) {
	    map[i] = FIRE; /* la cellule i prend feu */
	    break; /* plus besoin de chercher plus loin */
	  }
	}
      }
      break;
    }
  }
  free(map_copy);
  gl4dpScreenHasChanged();
}

static void dessine(void){
  gl4dpUpdateScreen(NULL);
}

int main(int argc, char ** argv) {
  SDL_Surface * s = SDL_LoadBMP("penguins.bmp");
  assert(s);
  if(!gl4duwCreateWindow(argc, argv, /* args du programme */
			 "GL4Dummies' Forest fire !!!", /* titre */
			 10, 10, s->w, s->h,
			 GL4DW_SHOWN)){

    return 1;
  }
  GLfloat * lum = gl4dpSDLSurfaceToLuminanceMap(s);
  gl4dpInitScreen();
  initForet(0.6, lum);
  // LightFire();
  LightFire2();

  atexit(quitte);

  gl4duwIdleFunc(generer);
  gl4duwDisplayFunc(dessine);
  gl4duwMainLoop();
  return 0;
}
